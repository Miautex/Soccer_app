/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.soccer.database.dao;

import edu.soccer.database.dto.Player;
import edu.soccer.database.dto.enums.Action;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Elias
 */

public class AuthorizationService {
    
    private static AuthorizationService instance = null;
   
   
    protected AuthorizationService() {
      // Exists only to defeat instantiation.
    }
    public static AuthorizationService getInstance() {
        if(instance == null) {
            
            instance = new AuthorizationService();
        }
      return instance;
    }
    
    
    public boolean isAutorizedToPerformAction(String key, Action action) {
        boolean isAutorized = false;
        Boolean isAdmin = null;
        
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "SELECT isadmin FROM players where loginkey = ? && isActive = true;";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setString(1, key);
            
            ResultSet rs = stmt.executeQuery();
            
            if(rs.next()){
                isAdmin = rs.getBoolean("isAdmin");
            }
            
            if (isAdmin != null) {
                isAutorized = getActionAuthorization(isAdmin, action);
            }
        }
        catch(Exception ex){
            isAutorized = false;
        }
        
        return isAutorized;
    }
    
    private boolean getActionAuthorization(boolean isAdmin, Action action) {
        boolean isAutorized = true;
        
        if (!isAdmin && 
            (action == Action.CREATE_GAME ||
            action == Action.CREATE_PLAYER ||
            action == Action.CREATE_PARTICIPATION ||
            action == Action.UPDATE_GAME ||
            action == Action.UPDATE_PARTICIPATION ||
            action == Action.DELETE_GAME ||
            action == Action.DELETE_PLAYER ||
            action == Action.DELETE_PARTICIPATION)) {

            isAutorized = false;
        }
        
        return isAutorized;
    }
    
}
