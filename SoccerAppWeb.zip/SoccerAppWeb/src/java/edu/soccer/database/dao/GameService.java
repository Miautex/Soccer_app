/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.soccer.database.dao;

import edu.soccer.database.dto.Game;
import edu.soccer.database.dto.Player;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Max
 */
public class GameService {
    
    private static GameService instance = null;
   
   
    protected GameService() {
      // Exists only to defeat instantiation.
    }
    public static GameService getInstance() {
        if(instance == null) {
            
            instance = new GameService();
        }
      return instance;
    }
    
    public ArrayList<Game> getAllGames() throws Exception{
        ArrayList<Game> ret = new ArrayList<Game>();
        
        try{
            Connection conn = IOManager.getInstance().getConnection();
            
            String select = "SELECT id, date, remark, scoreTeamA, scoreTeamB FROM games";
            PreparedStatement stmt = conn.prepareStatement(select);
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                ret.add(new Game(rs.getInt("id"),rs.getDate("date"),rs.getInt("scoreTeamA"),rs.getInt("scoreTeamB"),rs.getString("remark")));
            }
        }
        catch(Exception ex){
            throw new Exception(ex);
        }

        return ret;
    }
    
    public int updateGame(Game game) throws Exception{
        int ret = 0;
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "UPDATE games SET date = ?, remark = ?, scoreTeamA = ?, scoreTeamB = ? where id = ?";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setDate(1, new java.sql.Date(game.getDate().getTime()));
            stmt.setString(2, game.getRemark());
            stmt.setInt(3, game.getScoreTeamA());
            stmt.setInt(4, game.getScoreTeamB());
            stmt.setInt(5, game.getId());
            
            ret = stmt.executeUpdate();
            
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        return ret;
    }
    
    public ArrayList<Game> getGamesByDate(Date date) throws Exception{
        ArrayList<Game> ret = new ArrayList<Game>();
        
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "SELECT id, date, remark, scoreTeamA, scoreTeamB FROM games where date like ?";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setDate(1, new java.sql.Date(date.getTime()));
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                ret.add(new Game(rs.getInt("id"),rs.getDate("date"),rs.getInt("scoreTeamA"),rs.getInt("scoreTeamB"),rs.getString("remark")));
            }
        }
        catch(Exception ex){
            throw new Exception(ex);
        }

        return ret;
    }
    
    public int insertGame(Game newGame) throws Exception{
        int id = -1;
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "INSERT INTO games (date,remark,scoreTeamA,scoreTeamB) VALUES(?,?,?,?)";
            PreparedStatement stmt = conn.prepareStatement(select, Statement.RETURN_GENERATED_KEYS);
            stmt.setDate(1, new java.sql.Date(newGame.getDate().getTime()));
            stmt.setString(2, newGame.getRemark());
            stmt.setInt(3, newGame.getScoreTeamA());
            stmt.setInt(4, newGame.getScoreTeamB());
            
            
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            while(rs.next()){
                id = rs.getInt(1);
            }
            
            System.out.println("id gened:");
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        return id;
    }

    public int deleteGame(int id) throws Exception{
        int ret;
        try{
            Connection conn = IOManager.getInstance().getConnection();
            ParticipationService partService = ParticipationService.getInstance();
            
            //Get participations of game
            String select = "SELECT id FROM participation where idGame = ?";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setInt(1, id);
            
            ResultSet rs = stmt.executeQuery();
            
            //Delete participations of game
            while (rs.next()){
                System.out.println("Delete part " + rs.getInt(1));
                 partService.deleteParticipationById(rs.getInt(1));
            }
            
            //Delete game
            select = "DELETE FROM games where id = ?";
            stmt = conn.prepareStatement(select);
            stmt.setInt(1, id);
            
            ret = stmt.executeUpdate();
        }
        catch(Exception ex){
            ex.printStackTrace();
            throw new Exception(ex);
        }
        return ret;
    }
    
    public ArrayList<Game> getGamesByPlayer(int id) throws Exception{
        ArrayList<Game> ret = new ArrayList<Game>();
        
        try{
            Connection conn = IOManager.getInstance().getConnection();
            
            String select = "SELECT g.id, g.date, g.remark, g.scoreTeamA, g.scoreTeamB from participation" +
                                " inner join games g on g.id like idGame" +
                                " where idPlayer = ?";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setInt(1, id);
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Game g = new Game(rs.getInt("id"),rs.getDate("date"),rs.getInt("scoreTeamA"),rs.getInt("scoreTeamB"),rs.getString("remark"));
                ret.add(g);
            }
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        return ret;
    }
    
    
        public ArrayList<Game> getGamesByPlayer(int id, Date from, Date to) throws Exception{
        ArrayList<Game> ret = new ArrayList<Game>();
        
        try{
            Connection conn = IOManager.getInstance().getConnection();
            
            String select = "SELECT g.id, g.date, g.remark, g.scoreTeamA, g.scoreTeamB from participation" +
                                " inner join games g on g.id like idGame" +
                                " where idPlayer = ? AND g.date BETWEEN ? AND ?";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setInt(1, id);
            stmt.setDate(2, new java.sql.Date(from.getTime()));
            stmt.setDate(3, new java.sql.Date(to.getTime()));
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                ret.add(new Game(rs.getInt("id"),rs.getDate("date"),rs.getInt("scoreTeamA"),rs.getInt("scoreTeamB"),rs.getString("remark")));
            }
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        
        return ret;
    }
    
}
