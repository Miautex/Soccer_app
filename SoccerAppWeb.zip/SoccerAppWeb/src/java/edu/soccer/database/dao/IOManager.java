/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.soccer.database.dao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Max
 */
public class IOManager {
    Connection connection = null;
    private static final String USERNAME = "schueler";
    private static final String PASSWORD = "ib1sdaif";
    private static final String HOST = "192.168.142.245";
    private static final String HOST_EXTERN = "212.152.179.123";
    private static final String DB_SCHEME = "SOCCER_APP_4BG2";//"4BHIFS_2017_SOCCER_G2";
    
    
    private static IOManager instance = null;
   
   
    protected IOManager() {
      // Exists only to defeat instantiation.
    }
    public static IOManager getInstance() {
        if(instance == null) {
            instance = new IOManager();
            instance.connectToMysql();
        }
      return instance;
    }
    
    public void connectToMysql(){
        try{
            if (connection == null || connection.isClosed()) {
                Class.forName("com.mysql.jdbc.Driver");            
                connection= DriverManager.getConnection("jdbc:mysql://"+ HOST +":3306/"+ DB_SCHEME + "?useUnicode=true&characterEncoding=utf8",USERNAME,PASSWORD);  
            }            
            
        }catch (Exception ex){
            System.out.println("no connection ");
        }
    }
    
    public Connection getConnection(){
        this.connectToMysql();
        return connection;
    }
}
