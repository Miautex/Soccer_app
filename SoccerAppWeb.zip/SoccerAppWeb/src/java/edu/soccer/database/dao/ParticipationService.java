/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.soccer.database.dao;

import edu.soccer.database.dto.Participation;
import edu.soccer.database.dto.Player;
import edu.soccer.database.dto.enums.PlayerPosition;
import edu.soccer.database.dto.enums.Team;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Max
 */
public class ParticipationService {
    private static ParticipationService instance = null;
   
    protected ParticipationService() {
      // Exists only to defeat instantiation.
    }
    public static ParticipationService getInstance() {
        if(instance == null) {
            
            instance = new ParticipationService();
        }
      return instance;
    }

    public ArrayList<Participation> getAllParticipations() throws Exception {
        ArrayList<Participation> ret = new ArrayList<Participation>();
        
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "SELECT * FROM participation";
            PreparedStatement stmt = conn.prepareStatement(select);
            ResultSet rs = stmt.executeQuery();
            
            int idPlayer = -1;
            
            while(rs.next()){
                idPlayer = rs.getInt("idPlayer");
                int goalsGot = rs.getInt("goalsGot");
                int goalsShotDefault = rs.getInt("goalsShotDefault");
                int goalsShotHead = rs.getInt("goalsShotHead");
                int goalsShotHeadSnow = rs.getInt("goalsShotHeadSnow");
                int goalsShotPenalty = rs.getInt("goalsShotPenalty");
                int nutmeg = rs.getInt("nutmeg");
                String teamString = rs.getString("team");
                Team team;
                if("TEAM1".equals(teamString)){
                    team = Team.TEAM1;
                }
                else if ("TEAM2".equals(teamString)){
                    team = Team.TEAM2;
                }
                else{
                    team = Team.NULL;
                }
                PlayerPosition pp = PlayerPosition.valueOf(rs.getString("position"));
                Participation p = new Participation(new Player(),team,pp,goalsGot,goalsShotDefault,goalsShotHead,goalsShotHeadSnow,goalsShotPenalty,nutmeg);
                if(idPlayer != -1){
                    p.setPlayer(PlayerService.getInstance().getPlayerById(idPlayer));
                }
                ret.add(p);
            }
            
        }
        catch(Exception ex){
            ex.printStackTrace();
            throw new Exception(ex);
        }

        return ret;
    }
    
    public ArrayList<Participation> getParticipationsByGame(Integer gameId) throws Exception {
        ArrayList<Participation> ret = new ArrayList<Participation>();
        
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "SELECT * FROM participation WHERE idGame = ?";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setInt(1, gameId);
            
            ResultSet rs = stmt.executeQuery();
            
            int idPlayer = -1;
            
            while(rs.next()){
                idPlayer = rs.getInt("idPlayer");
                int goalsGot = rs.getInt("goalsGot");
                int goalsShotDefault = rs.getInt("goalsShotDefault");
                int goalsShotHead = rs.getInt("goalsShotHead");
                int goalsShotHeadSnow = rs.getInt("goalsShotHeadSnow");
                int goalsShotPenalty = rs.getInt("goalsShotPenalty");
                int nutmeg = rs.getInt("nutmeg");
                String teamString = rs.getString("team");
                Team team;
                if("TEAM1".equals(teamString)){
                    team = Team.TEAM1;
                }
                else if ("TEAM2".equals(teamString)){
                    team = Team.TEAM2;
                }
                else{
                    team = Team.NULL;
                }
                PlayerPosition pp = PlayerPosition.valueOf(rs.getString("position"));
                Participation p = new Participation(new Player(),team,pp,goalsGot,goalsShotDefault,goalsShotHead,goalsShotHeadSnow,goalsShotPenalty,nutmeg);
                if(idPlayer != -1){
                    p.setPlayer(PlayerService.getInstance().getPlayerById(idPlayer));
                }
                ret.add(p);
            }
            
        }
        catch(Exception ex){
            ex.printStackTrace();
            throw new Exception(ex);
        }

        return ret;
    }
    
    public Participation getParticipationById(Integer id) throws Exception {
        Participation ret = null;
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "SELECT * from participation where id = ?";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setInt(1, id);
            
            ResultSet rs = stmt.executeQuery();
            int idPlayer = -1;
            while(rs.next()){
                idPlayer = rs.getInt("idPlayer");
                int goalsGot = rs.getInt("goalsGot");
                int goalsShotDefault = rs.getInt("goalsShotDefault");
                int goalsShotHead = rs.getInt("goalsShotHead");
                int goalsShotHeadSnow = rs.getInt("goalsShotHeadSnow");
                int goalsShotPenalty = rs.getInt("goalsShotPenalty");
                int nutmeg = rs.getInt("nutmeg");
                Team team = Team.valueOf(rs.getString("team"));
                PlayerPosition pp = PlayerPosition.valueOf(rs.getString("position"));
                ret = new Participation(new Player(),team,pp,goalsGot,goalsShotDefault,goalsShotHead,goalsShotHeadSnow,goalsShotPenalty,nutmeg);
            }
            
            if(idPlayer != -1){
                ret.setPlayer(PlayerService.getInstance().getPlayerById(idPlayer));
            }
            
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        return ret;
    }
    
    public int deleteParticipationById(Integer id) throws Exception {
        int ret = 0,
                player_id = -1;
        
        try{
            Connection conn = IOManager.getInstance().getConnection();
            
            //Select playerID
            String select = "SELECT idPlayer FROM participation where id = ?";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setInt(1, id);
            
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()){
                player_id = rs.getInt(1);
            }
            
            //Delete participation
            select = "DELETE FROM participation where id = ?";
            stmt = conn.prepareStatement(select);
            stmt.setInt(1, id);
            
            ret = stmt.executeUpdate();
            
            //Delete player if deactivated and has no other participations
            PlayerService.getInstance().deleteIfUnused(player_id);
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        return ret;
    }

    public int insertParticipation(Participation p, int idGame, int idPlayer) throws Exception {
        int ret = 0;
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "INSERT INTO participation (idGame,idPlayer,goalsShotDefault,goalsShotHead,goalsShotHeadSnow,goalsShotPenalty,nutmeg,team,position,goalsGot) VALUES(?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setInt(1, idGame);
            stmt.setInt(2, idPlayer);
            stmt.setInt(3, p.getNumGoalsShotDefault());
            stmt.setInt(4, p.getNumGoalsShotHead());
            stmt.setInt(5, p.getNumGoalsShotHeadSnow());
            stmt.setInt(6, p.getNumGoalsShotPenalty());
            stmt.setInt(7, p.getNumNutmeg());
            stmt.setString(8, p.getTeam().toString());
            stmt.setString(9, p.getPosition().toString());
            stmt.setInt(10, p.getNumGoalsGot());
            
            ret = stmt.executeUpdate();
        }
        catch(Exception ex){
            ex.printStackTrace();
            throw new Exception(ex);
        }
        return ret;
    }
    
    public int updateParticipation(Participation p, int idGame, int idPlayer) throws Exception {
        int ret = 0;
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "UPDATE participation SET goalsShotDefault=?, goalsShotHead=?, goalsShotHeadSnow=?,"
                    + "goalsShotPenalty=?, nutmeg=?, team=?, position=?, goalsGot=? "
                    + "WHERE idGame=? AND idPlayer=?";
            
            PreparedStatement stmt = conn.prepareStatement(select);
            
            stmt.setInt(1, p.getNumGoalsShotDefault());
            stmt.setInt(2, p.getNumGoalsShotHead());
            stmt.setInt(3, p.getNumGoalsShotHeadSnow());
            stmt.setInt(4, p.getNumGoalsShotPenalty());
            stmt.setInt(5, p.getNumNutmeg());
            stmt.setString(6, p.getTeam().toString());
            stmt.setString(7, p.getPosition().toString());
            stmt.setInt(8, p.getNumGoalsGot());
             stmt.setInt(9, idGame);
            stmt.setInt(10, idPlayer);
            
            ret = stmt.executeUpdate();
        }
        catch(Exception ex){
            ex.printStackTrace();
            throw new Exception(ex);
        }
        return ret;
    }




    
    
    
}
