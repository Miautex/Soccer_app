/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.soccer.database.dao;

import edu.soccer.database.dto.Game;
import edu.soccer.database.dto.Player;
import edu.soccer.database.dto.PlayerPositionRequest;
import edu.soccer.database.dto.PlayerStatistics;
import edu.soccer.database.dto.enums.PlayerPosition;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import java.util.UUID;
import static java.util.UUID.randomUUID;

/**
 *
 * @author Max
 */
public class PlayerService {
    
    private static PlayerService instance = null;
   
   
    protected PlayerService() {
      // Exists only to defeat instantiation.
    }
    public static PlayerService getInstance() {
        if(instance == null) {
            
            instance = new PlayerService();
        }
      return instance;
    }
    

    public ArrayList<Player> getAllPlayers() throws Exception{
        ArrayList<Player> ret = new ArrayList<Player>();
        
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "SELECT id, username, name, isadmin FROM players WHERE isActive = true";
            PreparedStatement stmt = conn.prepareStatement(select);
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Player newPlayer = new Player(rs.getInt("id"),rs.getString("username"),rs.getString("name"),rs.getBoolean("isAdmin"));
                ret.add(newPlayer);
                
                for (PlayerPosition pp: getPositionsById(newPlayer.getId(), conn)) {
                    newPlayer.addPosition(pp);
                }
            }
            
            rs.close();
            
            for(Player pl : ret){
                getMetaDataForPlayer(pl, conn);
            }
            
            
        }
        catch(Exception ex){
            ex.printStackTrace();
            throw new Exception(ex);
        }

        return ret;
    }
    
    public String login(String username, String password_enc) throws Exception {
        String ret = "";
        
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "SELECT loginkey FROM players where username like ? AND password like ? AND isActive = true";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setString(1, username);
            stmt.setString(2, password_enc);
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                ret = rs.getString("loginkey");
            }
            
            if (ret == null || ret.isEmpty()) {
                throw new Exception("invalid credentials");
            }
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        
        return ret;
    }
        
    public String getPassword(String username) throws Exception{
        String ret = "";
        
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "SELECT password FROM players where username like ? AND isActive = true";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setString(1, username);
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                ret = rs.getString("password");
            }
            
            if (ret == null || ret.isEmpty()) {
                throw new Exception("no password found");
            }
        }
        catch(Exception ex){
            throw new Exception(ex);
        }

        return ret;
    }
    
    public int updatePlayer(Player player) throws Exception{
        int res = 0;
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "UPDATE players SET username = ?, name = ?, isadmin = ? where id = ?";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setString(1, player.getUsername());
            stmt.setString(2, player.getName());
            stmt.setBoolean(3, player.isAdmin());
            stmt.setString(4, player.getId() + "");
            
            res = stmt.executeUpdate();
            
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        return res;
    }
    
    public Player getPlayerByUsername(String username) throws Exception{
        Player ret = null;
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "SELECT id, username, name, isadmin FROM players where username = ?";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setString(1, username);
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                ret = new Player(rs.getInt("id"),rs.getString("username"),rs.getString("name"),rs.getBoolean("isAdmin"));
                getMetaDataForPlayer(ret, conn);
                
                for (PlayerPosition pp: getPositionsById(ret.getId(), conn)) {
                    ret.addPosition(pp);
                }
            }
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        
        return ret;
    }
    
    private ArrayList<PlayerPosition> getPositionsById(int id, Connection conn) throws Exception{
        ArrayList<PlayerPosition> ret = new ArrayList<>();
        try{
            String select = "SELECT position FROM playersGamePositions WHERE id_player = ?";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setInt(1, id);
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                ret.add(PlayerPosition.valueOf(rs.getString("position")));
            }
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        
        return ret;
    }
    
    public int setPositionById(int id, PlayerPositionRequest positionsRequest) throws Exception{
        int ret = -1;
        
        try{
            Connection conn = IOManager.getInstance().getConnection();
            ArrayList<PreparedStatement> stmtsToExecute = new ArrayList<>();
            
            String insert = "INSERT INTO playersGamePositions (id_player, position) VALUES(?, ?)";
            String delete = "DELETE FROM playersGamePositions WHERE id_player = ? AND position = ?";
            
            //ATTACK
            PreparedStatement stmtATT;
            if (positionsRequest.isATTACK()) {
                stmtATT = conn.prepareStatement(insert);
            }
            else {
                stmtATT = conn.prepareStatement(delete);
            }
            stmtATT.setInt(1, id);
            stmtATT.setString(2, PlayerPosition.ATTACK.toString());
            stmtsToExecute.add(stmtATT);
            
            //DEFENSE
            PreparedStatement stmtDEF;
            if (positionsRequest.isDEFENSE()) {
                stmtDEF = conn.prepareStatement(insert);
            }
            else {
                stmtDEF = conn.prepareStatement(delete);
            }
            stmtDEF.setInt(1, id);
            stmtDEF.setString(2, PlayerPosition.DEFENSE.toString());
            stmtsToExecute.add(stmtDEF);
            
            //GOAL
            PreparedStatement stmtGOA;
            if (positionsRequest.isGOAL()) {
                stmtGOA = conn.prepareStatement(insert);
            }
            else {
                stmtGOA = conn.prepareStatement(delete);
            }
            stmtGOA.setInt(1, id);
            stmtGOA.setString(2, PlayerPosition.GOAL.toString());
            stmtsToExecute.add(stmtGOA);
            
            //MIDFIELD
            PreparedStatement stmtMID;
            if (positionsRequest.isMIDFIELD()) {
                stmtMID = conn.prepareStatement(insert);
            }
            else {
                stmtMID = conn.prepareStatement(delete);
            }
            stmtMID.setInt(1, id);
            stmtMID.setString(2, PlayerPosition.MIDFIELD.toString());
            stmtsToExecute.add(stmtMID);
            
            for (PreparedStatement prepStmt : stmtsToExecute) {
                try {
                     prepStmt.executeUpdate();
                }
                catch (SQLException ex) { 
                    //Occours if position is already set/unset, so no handling needed
                }
            }

        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        return ret;
    }

    public Player getPlayerById(int id) throws Exception{
        Player ret = null;
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "SELECT id, username, name, isadmin FROM players where id = ?";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setInt(1, id);
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                ret = new Player(rs.getInt("id"),rs.getString("username"),rs.getString("name"),rs.getBoolean("isAdmin"));
                getMetaDataForPlayer(ret, conn);
            }
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        
        return ret;
    }
    
    public int insertPlayer(Player newPlayer) throws Exception{
        int id = -1;
        String loginKey = generateRandomLoginKey(); 
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "INSERT INTO players (username,name,isAdmin,password,isActive,loginkey) VALUES(?,?,?,?,?,?)";
            PreparedStatement stmt = conn.prepareStatement(select, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, newPlayer.getUsername());
            stmt.setString(2, newPlayer.getName());
            stmt.setBoolean(3, newPlayer.isAdmin());
            stmt.setString(4, "standard");
            stmt.setBoolean(5, true);
            stmt.setString(6, loginKey);
            
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            while(rs.next()){
                id = rs.getInt(1);
            }
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        return id;
    }
    
    private String generateRandomLoginKey() {
        String key = null;
        String uuid = UUID.randomUUID().toString();
        try {
            MessageDigest m = MessageDigest.getInstance("MD5");
            m.update(uuid.getBytes(), 0, uuid.length());
            key = new BigInteger(1, m.digest()).toString(16);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return key;
    }
    
    public int deletePlayer(int id) throws Exception {
        int ret = 0;
        
        try{
            if (getNumOfParticipations(id) == 0) {
                Connection conn = IOManager.getInstance().getConnection();
                
                //Delete PlayerPositions
                String select = "DELETE FROM playersGamePositions WHERE id_player = ?";
                PreparedStatement stmt = conn.prepareStatement(select);
                stmt.setInt(1, id);
                ret = stmt.executeUpdate();
                
                //Delete Player
                select = "DELETE FROM players WHERE id = ?";
                stmt = conn.prepareStatement(select);
                stmt.setInt(1, id);
                ret = stmt.executeUpdate();
            }
            else {
                ret = deactivatePlayer(id);
            }
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        return ret;
    }
    
    public int deactivatePlayer(int id) throws Exception {
        int ret = 0;
        String username_deactivated = "~" + getPlayerById(id).getUsername() + "~";
        
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "UPDATE players SET isActive = false, username = CONCAT(?, CURRENT_TIMESTAMP()) where id = ?";
            PreparedStatement stmt = conn.prepareStatement(select, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, username_deactivated);
            stmt.setInt(2, id);
            
            ret = stmt.executeUpdate();
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        return ret;
    }
    
    public void deleteIfUnused(int playerID) throws Exception {
        if (!isPlayerActive(playerID) && getNumOfParticipations(playerID) == 0) {
            deletePlayer(playerID);
        }
    }
    
    private boolean isPlayerActive(int playerID) throws SQLException {
        boolean isActive = true;
        
        Connection conn = IOManager.getInstance().getConnection();
        String select = "SELECT isActive FROM players WHERE id = ?";
        PreparedStatement stmt = conn.prepareStatement(select);
        stmt.setInt(1, playerID);
        
        ResultSet rs = stmt.executeQuery();
            
        if (rs.next()){
            isActive = rs.getBoolean(1);
        }
        
        return isActive;
    }
    
    private int getNumOfParticipations(int playerID) throws Exception {
        int num = 0;
        
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "SELECT count(*) FROM participation WHERE idPlayer = ?";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setInt(1, playerID);
            
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()){
                num = rs.getInt(1);
            }
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        
        return num;
        
    }
    
    public int setPassword(int id, String password) throws Exception{
        int ret = 0;
        
        try{
            Connection conn = IOManager.getInstance().getConnection();
            String select = "UPDATE players SET password = ? where id = ?";
            PreparedStatement stmt = conn.prepareStatement(select);
            stmt.setString(1, password);
            stmt.setInt(2, id);
            
            ret = stmt.executeUpdate();
            
        }
        catch(Exception ex){
            throw new Exception(ex);
        }
        return ret;
    }

    private void getMetaDataForPlayer(Player pl, Connection conn) throws Exception {
        try{
            calculateWinLossMetaData(pl, conn);
            calculateGoalsMetaData(pl, conn);
            calculatePositionMetaData(pl, conn);
            
        }catch(Exception ex){
            throw new Exception(ex);
        }
    
    }
    
    private void calculatePositionMetaData(Player pl, Connection conn) throws Exception {
        String newselect = "SELECT count(*), position from participation where idPlayer = ? group by position;";
        
        PreparedStatement stmt2 = conn.prepareStatement(newselect);
        stmt2.setInt(1, pl.getId());
        ResultSet rs2 = stmt2.executeQuery();
        
        int numAttack = 0,
            numDefense = 0,
            numMidfield = 0,
            numGoal = 0;
        
        while(rs2.next()){
            switch (rs2.getString(2)) {
                case "ATTACK":
                    numAttack = rs2.getInt(1);
                    break;
                case "DEFENSE":
                    numDefense = rs2.getInt(1);
                    break;
                case "MIDFIELD":
                    numMidfield = rs2.getInt(1);
                    break;
                case "GOAL":
                    numGoal = rs2.getInt(1);
                    break;
            }
        }
        
        pl.getStatistics().setNumPosAttack(numAttack);
        pl.getStatistics().setNumPosDefense(numDefense);
        pl.getStatistics().setNumPosMidfield(numMidfield);
        pl.getStatistics().setNumPosGoal(numGoal);
    }
    
    private void calculateGoalsMetaData(Player pl, Connection conn) throws Exception {
        String newselect = "SELECT sum(goalsGot), sum(goalsShotDefault), sum(goalsShotHead), "
                + "sum(goalsShotHeadSnow), sum(goalsShotPenalty), sum(nutmeg) "
                + "from participation where idPlayer = ?";
        
        PreparedStatement stmt2 = conn.prepareStatement(newselect);
        stmt2.setInt(1, pl.getId());
        ResultSet rs2 = stmt2.executeQuery();
        
        int numGoalsGot = 0,
            numGoalsShotDefault = 0,
            numGoalsShotHead = 0,
            numGoalsShotHeadSnow = 0,
            numGoalsShotPenalty = 0,
            numNutmeg = 0;
        
        while(rs2.next()){
            numGoalsGot = rs2.getInt(1);
            numGoalsShotDefault = rs2.getInt(2);
            numGoalsShotHead = rs2.getInt(3);
            numGoalsShotHeadSnow = rs2.getInt(4);
            numGoalsShotPenalty = rs2.getInt(5);
            numNutmeg = rs2.getInt(6);
        }
        
        pl.getStatistics().setNumGoalsGot(numGoalsGot);
        pl.getStatistics().setNumGoalsShot(numGoalsShotDefault);
        pl.getStatistics().setNumGoalsShotHead(numGoalsShotHead);
        pl.getStatistics().setNumGoalsShotHeadSnow(numGoalsShotHeadSnow);
        pl.getStatistics().setNumGoalsShotPenalty(numGoalsShotPenalty);
        pl.getStatistics().setNumNutmeg(numNutmeg);
}
    
    private void calculateWinLossMetaData(Player pl, Connection conn) throws Exception {
        String newselect = "SELECT team, scoreTeamA, scoreTeamB FROM participation p " +
                        "inner join players pl on " +
                        "pl.id = p.idPlayer " +
                        "inner join games g on g.id = p.idGame " +
                        "where pl.id = ?";
        PreparedStatement stmt2 = conn.prepareStatement(newselect);
        stmt2.setInt(1, pl.getId());
        ResultSet rs2 = stmt2.executeQuery();

        int numWins = 0;
        int numDefeats = 0;
        int numDraws = 0;
        float goalDifference = 0;
        int anz = 0;

        while(rs2.next()){
            String team = rs2.getString(1);
            int scoreTeamA = rs2.getInt(2);
            int scoreTeamB = rs2.getInt(3);
            int scoreDif = scoreTeamA-scoreTeamB;

            if("TEAM1".equals(team)){
                if(scoreDif < 0){
                    numDefeats++;
                }
                else if(scoreDif > 0){
                    numWins++;
                }
                else{
                    numDraws++;
                }

                goalDifference = goalDifference + scoreDif;
            }
            else{
                if(scoreDif > 0){
                    numDefeats++;
                }
                else if(scoreDif < 0){
                    numWins++;
                }
                else{
                    numDraws++;
                }

                goalDifference = goalDifference + (scoreDif*-1);
            }
            anz++;
        }
        if(anz != 0){
            goalDifference = goalDifference / anz; 
        }

        pl.getStatistics().setNumGamesPlayed(anz);
        pl.getStatistics().setAvgGoalDifference(goalDifference);
        pl.getStatistics().setNumDefeats(numDefeats);
        pl.getStatistics().setNumWins(numWins);
        pl.getStatistics().setNumDraws(numDraws);
    }
    
    
}
