package edu.soccer.database.dto.enums;
public enum PlayerPosition {
    GOAL, MIDFIELD, ATTACK, DEFENSE
}