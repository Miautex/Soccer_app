package edu.soccer.database.dto.enums;
/**
* Created by Wilscher Marco
*/
public enum Team {
    TEAM1, TEAM2, NULL
}