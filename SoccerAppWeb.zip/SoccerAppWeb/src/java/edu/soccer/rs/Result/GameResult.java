package edu.soccer.rs.Result;

import edu.soccer.database.dto.Game;
import edu.soccer.rs.Result.Result;
import java.io.Serializable;
import java.util.ArrayList;
import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class GameResult extends Result{

	private ArrayList<Game> content;
	
	public GameResult() {}

	public ArrayList<Game> getContent() {
		return content;
	}

	public void setContent(ArrayList<Game> content) {
		this.content = content;
	}


	
	
}
	