/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.soccer.rs.Result;

import edu.soccer.database.dto.Location;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Elias
 */
@XmlRootElement
public class LocationResult extends Result {
    private Location content;
	
	public LocationResult() {
	}

	public Location getContent() {
		return content;
	}

	public void setContent(Location loc) {
		this.content = loc;
	}
}
