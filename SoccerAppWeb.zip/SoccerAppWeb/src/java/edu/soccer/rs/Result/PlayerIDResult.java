/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.soccer.rs.Result;

import edu.soccer.database.dto.Player;
import java.util.ArrayList;

/**
 *
 * @author Elias
 */

public class PlayerIDResult extends Result{

	private ArrayList<Integer> content;
	
	public PlayerIDResult() {
	}

	public ArrayList<Integer> getContent() {
		return content;
	}

	public void setContent(ArrayList<Integer> content) {
		this.content = content;
	}
}