/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.soccer.rs.Result;

import edu.soccer.database.dto.enums.PlayerPosition;
import java.util.ArrayList;


public class PositionResult extends Result{

	private ArrayList<PlayerPosition> content;
	
	public PositionResult() {
	}

	public ArrayList<PlayerPosition> getContent() {
		return content;
	}

	public void setContent(ArrayList<PlayerPosition> content) {
		this.content = content;
	}
}
