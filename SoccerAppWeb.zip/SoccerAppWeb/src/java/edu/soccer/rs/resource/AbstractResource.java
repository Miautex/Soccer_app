package edu.soccer.rs.resource;

import edu.soccer.rs.Error.Error;
import edu.soccer.rs.Result.Result;


public abstract class AbstractResource {

	public void handelAndThrowError(Exception e, Result r){
		Error error = new Error();
		error.setErrorCode(0); 
		error.setErrorMessage(e.getMessage());
		r.setError(error);
		r.setSuccess(false);
		System.out.println("[Error Info] : " + e.toString());
	}
}
