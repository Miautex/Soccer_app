package edu.soccer.rs.resource;

import edu.soccer.database.dao.AuthorizationService;
import edu.soccer.database.dto.Game;
import edu.soccer.database.dao.GameService;
import edu.soccer.database.dto.enums.Action;
import edu.soccer.rs.Result.GameResult;
import edu.soccer.rs.Result.Result;
import edu.soccer.rs.Result.SingleGameResult;
import edu.soccer.rs.resource.AbstractResource;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

@Path("game")
public class GameResource extends AbstractResource {

	@GET
	@Produces(value = { MediaType.APPLICATION_JSON})
	public Response getAllGames(@Context HttpServletRequest httpServletRequest, 
                @QueryParam(value = "loginKey") String loginKey) {
                
                ResponseBuilder response = Response.status(Status.ACCEPTED);
		GameResult result = new GameResult();
                
		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.READ_GAME)) {
                        System.out.println("Authorized");
                        ArrayList<Game> games = GameService.getInstance().getAllGames();
                        result.setContent(games);
                        result.setSuccess(true);
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }     
			
		} catch (Exception e) {
			handelAndThrowError(e, result);
		}
                finally {
                    response.entity(result);
                }

		return response.build();
	}

	@PUT
	@Consumes(value = MediaType.APPLICATION_JSON)
	@Produces(value = { MediaType.APPLICATION_JSON})
	public Response updateGame(@Context HttpServletRequest httpServletRequest, final Game game,
                @QueryParam(value = "loginKey") String loginKey) {

                ResponseBuilder response = Response.status(Status.ACCEPTED);
		Result r = new Result();

		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.UPDATE_GAME)) {
			if(GameService.getInstance().updateGame(game) == 1){
                            r.setSuccess(true);
                        }
                        else{
                            r.setSuccess(false);
                        }
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }   
                    
		} catch (Exception e) {
			handelAndThrowError(e, r);
		}
                finally {
                    response.entity(r);
                }

		return response.build();

	}

	@GET
	@Path("/byDate/{date}")
	@Produces(value = { MediaType.APPLICATION_JSON})
	public Response getGamesByDate(@Context HttpServletRequest httpServletRequest,
			@PathParam(value = "date") String date,
                        @QueryParam(value = "loginKey") String loginKey) {

                ResponseBuilder response = Response.status(Status.ACCEPTED);
		GameResult r = new GameResult();

		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.READ_GAME)) {
			if (date != null) {
				SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
				Date realDate = simple.parse(date);

				ArrayList<Game> games = GameService.getInstance().getGamesByDate(realDate);
				r.setContent(games);
				r.setSuccess(true);
			} else {
				throw new Exception("Date is null");
                        }
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }   
		} catch (Exception e) {
			handelAndThrowError(e, r);
		}
                finally {
                    response.entity(r);
                }

		return response.build();
	}

	@GET
	@Path("/byPlayerId/{id}")
	@Produces(value = { MediaType.APPLICATION_JSON})
	public Response getGamesByPlayer(@Context HttpServletRequest httpServletRequest,
			@PathParam(value = "id") Integer id, @QueryParam(value = "dateFrom") String dateFrom,
			@QueryParam(value = "dateTo") String dateTo,
                        @QueryParam(value = "loginKey") String loginKey) {

                ResponseBuilder response = Response.status(Status.ACCEPTED);
		GameResult r = new GameResult();
		
		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.READ_GAME)) {
			if(id != null){
				SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
				ArrayList<Game> content;
				
				if(dateFrom != null && dateTo != null){
					Date from = simple.parse(dateFrom);
					Date to = simple.parse(dateTo);
					
					content = GameService.getInstance().getGamesByPlayer(id, from, to);
				} else {
					content = GameService.getInstance().getGamesByPlayer(id);
				}
				r.setContent(content);
				r.setSuccess(true);

			} else {
				throw new Exception("Is des eia ernst das ihr de ID vergessts, trotz docu 666 demoted");
			}
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }   
		} catch (Exception e) {
			handelAndThrowError(e, r);
		}
                finally {
                    response.entity(r);
                }
                
		return response.build();
	}

	@POST
	@Consumes(value = MediaType.APPLICATION_JSON)
	@Produces(value = { MediaType.APPLICATION_JSON})
	public Response insertGame(@Context HttpServletRequest httpServletRequest, final Game g,
                @QueryParam(value = "loginKey") String loginKey) {

                ResponseBuilder response = Response.status(Status.CREATED);
		SingleGameResult r = new SingleGameResult();
                

		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.CREATE_GAME)) {
			g.setId(GameService.getInstance().insertGame(g));
			r.setSuccess(true);
                        r.setContent(g);
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }   
		} catch (Exception e) {
                    handelAndThrowError(e, r);
		}
                finally {
                    response.entity(r);
                }

		return response.build();
	}

	@DELETE
	@Path("{id}")
	@Produces(value = { MediaType.APPLICATION_JSON})
	public Response deleteGame(@Context HttpServletRequest httpServletRequest, 
                @PathParam(value = "id") Integer id,
                @QueryParam(value = "loginKey") String loginKey) {

                ResponseBuilder response = Response.status(Status.OK);
		Result r = new Result();

		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.DELETE_GAME)) {
			if (id != null) {
                            if(GameService.getInstance().deleteGame(id) == 1){
                                r.setSuccess(true);
                            }else{
                                r.setSuccess(false);
                            }
			} else {
				throw new Exception("Id not set");
			}
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }   
		} catch (Exception e) {
			handelAndThrowError(e, r);
		}
                finally {
                    response.entity(r);
                }

		return response.build();
	}
}
