package edu.soccer.rs.resource;

import edu.soccer.database.dao.AuthorizationService;
import edu.soccer.database.dao.ParticipationService;
import edu.soccer.database.dto.Participation;
import edu.soccer.database.dto.enums.Action;
import edu.soccer.rs.Result.ParticipationResult;
import edu.soccer.rs.Result.Result;
import edu.soccer.rs.Result.SingleParticipationResult;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

@Path("participation")
public class ParticipationResource extends AbstractResource {

	@GET
	@Produces(value = { MediaType.APPLICATION_JSON })
	public Response getAllParticipations(@Context HttpServletRequest httpServletRequest,
                @QueryParam(value = "loginKey") String loginKey) {

                ResponseBuilder response = Response.status(Status.ACCEPTED);
		ParticipationResult r = new ParticipationResult();

		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.READ_PARTICIPATION)) {
			ArrayList<Participation> all = ParticipationService.getInstance().getAllParticipations();
			r.setContent(all);
			r.setSuccess(true);
                        response.entity(r);
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }
		} catch (Exception e) {
			handelAndThrowError(e, r);
		}

		return response.build();
	}

	@GET
	@Path("/{id}")
	@Produces(value = { MediaType.APPLICATION_JSON })
	public Response getParticipationById(@Context HttpServletRequest httpServletRequest,
			@PathParam(value = "id") Integer id,
                        @QueryParam(value = "loginKey") String loginKey) {

                ResponseBuilder response = Response.status(Status.ACCEPTED);
		SingleParticipationResult r = new SingleParticipationResult();
		
		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.READ_PARTICIPATION)) {
			Participation p = ParticipationService.getInstance().getParticipationById(id);
			r.setContent(p);
			r.setSuccess(true);
                        response.entity(r);
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }
		} catch (Exception e) {
			handelAndThrowError(e, r);
		}
		
		return response.build();
	}
        
        @GET
	@Path("/byGame/{id}")
	@Produces(value = { MediaType.APPLICATION_JSON })
	public Response getParticipationByGame(@Context HttpServletRequest httpServletRequest,
			@PathParam(value = "id") Integer idGame,
                        @QueryParam(value = "loginKey") String loginKey) {

                ResponseBuilder response = Response.status(Status.ACCEPTED);
		ParticipationResult r = new ParticipationResult();
		
		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.READ_PARTICIPATION)) {
			ArrayList<Participation> all = ParticipationService.getInstance().getParticipationsByGame(idGame);
			r.setContent(all);
			r.setSuccess(true);
                        response.entity(r);
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }
		} catch (Exception e) {
			handelAndThrowError(e, r);
		}

		return response.build();
	}

	@POST
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Produces(value = { MediaType.APPLICATION_JSON })
	public Response createParticipation(@Context HttpServletRequest httpServletRequest, final Participation p, 
                @QueryParam(value = "idGame") String idGame,
                @QueryParam(value = "idPlayer") String idPlayer,
                @QueryParam(value = "loginKey") String loginKey) {

                ResponseBuilder response = Response.status(Status.ACCEPTED);
		Result r = new Result();
                int iidGame = Integer.valueOf(idGame);
                int iidPlayer = Integer.valueOf(idPlayer);
		
		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.CREATE_PARTICIPATION)) {
			if(ParticipationService.getInstance().insertParticipation(p,iidGame,iidPlayer) == 1){
                            r.setSuccess(true);  
                        }
                        else{
                            r.setSuccess(false);
                        }
                        response.entity(r);
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }
			
		} catch (Exception e) {
			handelAndThrowError(e, r);
		}
		
		
		return response.build();
	}
        
        @PUT
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Produces(value = { MediaType.APPLICATION_JSON })
	public Response updateParticipation(@Context HttpServletRequest httpServletRequest, final Participation p, 
                @QueryParam(value = "idGame") String idGame,
                @QueryParam(value = "idPlayer") String idPlayer,
                @QueryParam(value = "loginKey") String loginKey) {

                ResponseBuilder response = Response.status(Status.ACCEPTED);
		Result r = new Result();
                int iidGame = Integer.valueOf(idGame);
                int iidPlayer = Integer.valueOf(idPlayer);
		
		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.UPDATE_PARTICIPATION)) {
			if(ParticipationService.getInstance().updateParticipation(p,iidGame,iidPlayer) == 1){
                            r.setSuccess(true);  
                        }
                        else{
                            r.setSuccess(false);
                        }
                        response.entity(r);
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }
			
		} catch (Exception e) {
			handelAndThrowError(e, r);
		}
		
		
		return response.build();
	}
	
	@DELETE
	@Path("/{id}")
	@Produces(value = { MediaType.APPLICATION_JSON })
	public Response deleteParticipation(@Context HttpServletRequest httpServletRequest,
			@PathParam(value = "id") Integer id,
                        @QueryParam(value = "loginKey") String loginKey){
		
                ResponseBuilder response = Response.status(Status.ACCEPTED);
		Result r = new Result();
		
		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.DELETE_PARTICIPATION)) {
                        if(ParticipationService.getInstance().deleteParticipationById(id) == 1){
                            r.setSuccess(true);
                        }
                        else{
                            r.setSuccess(false);
                        }
                        response.entity(r);
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }
			
		} catch (Exception e) {
			handelAndThrowError(e, r);
		}
		
		return response.build();
	}
}
