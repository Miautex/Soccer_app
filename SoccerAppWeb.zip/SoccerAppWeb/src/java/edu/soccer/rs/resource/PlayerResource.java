package edu.soccer.rs.resource;

import edu.soccer.database.dao.AuthorizationService;
import edu.soccer.database.dao.PlayerService;
import edu.soccer.database.dto.LoginCredentials;
import edu.soccer.database.dto.Player;
import edu.soccer.database.dto.PlayerPositionRequest;
import edu.soccer.database.dto.enums.Action;
import edu.soccer.database.dto.enums.PlayerPosition;
import edu.soccer.rs.Result.PlayerResult;
import edu.soccer.rs.Result.PositionResult;
import edu.soccer.rs.Result.Result;
import edu.soccer.rs.Result.SinglePlayerResult;
import edu.soccer.rs.resource.AbstractResource;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

@Path("player")
public class PlayerResource extends AbstractResource {

	@GET
	@Produces(value = { MediaType.APPLICATION_JSON})
	public Response getAllPlayers(@Context HttpServletRequest httpServletRequest,
                @QueryParam(value = "loginKey") String loginKey) {

                ResponseBuilder response = Response.status(Status.ACCEPTED);
		PlayerResult result = new PlayerResult();

		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.READ_PLAYER)) {
			ArrayList<Player> players = PlayerService.getInstance().getAllPlayers();
			result.setContent(players);
			result.setSuccess(true);
                        response.entity(result);
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }
		} catch (Exception e) {
			handelAndThrowError(e, result);
		}

		return response.build();
	}

	@PUT
	@Consumes(value = MediaType.APPLICATION_JSON)
	@Produces(value = { MediaType.APPLICATION_JSON})
	public Response updatePlayer(@Context HttpServletRequest httpServletRequest, final Player p,
                @QueryParam(value = "loginKey") String loginKey) {

                ResponseBuilder response = Response.status(Status.ACCEPTED);
		Result r = new Result();

		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.UPDATE_PLAYER)) {
                        if(PlayerService.getInstance().updatePlayer(p) == 1){
                            r.setSuccess(true);
                        }
                        else{
                            r.setSuccess(false);
                        }
                        response.entity(r);
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }
		} catch (Exception e) {
			handelAndThrowError(e, r);
		}

		return response.build();
	}
        
        @PUT
	@Path("positions/{playerid}")
        @Consumes(value = MediaType.APPLICATION_JSON)
	@Produces(value = { MediaType.APPLICATION_JSON})
	public Response setPosition(@Context HttpServletRequest httpServletRequest,
			@PathParam(value = "playerid") String id, final PlayerPositionRequest positionsRequest,
                        @QueryParam(value = "loginKey") String loginKey) {
            
                ResponseBuilder response = Response.status(Status.ACCEPTED);
		Result r = new Result();
                
		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.UPDATE_PLAYER)) {
                        if (id != null) {
                                PlayerService.getInstance().setPositionById(Integer.parseInt(id), positionsRequest);
                                r.setSuccess(true);
                                response.entity(r);
                        } else {
                                throw new Exception("Id not set");
                        }
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }
		} catch (Exception e) {
			handelAndThrowError(e, r);
                        e.printStackTrace();
		}

		return response.build();
	}
        
	@GET
	@Path("{playername}")
	@Produces(value = { MediaType.APPLICATION_JSON})
	public Response getPlayer(@Context HttpServletRequest httpServletRequest,
			@PathParam(value = "playername") String name,
                        @QueryParam(value = "loginKey") String loginKey) throws Exception {

                ResponseBuilder response = Response.status(Status.ACCEPTED);
		SinglePlayerResult r = new SinglePlayerResult();

                if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.UPDATE_PLAYER)) {
                    if (name != null) {

                            Player p = PlayerService.getInstance().getPlayerByUsername(name);
                            r.setContent(p);
                            if(p != null){
                                r.setSuccess(true);
                            }
                            else{
                                r.setSuccess(false);
                            }
                            response.entity(r);

                    } else {
                            throw new Exception("Name is null");
                    }
                }
                else {
                    response.status(Status.UNAUTHORIZED);
                }

		return response.build();
	}

	@POST
	@Consumes(value = MediaType.APPLICATION_JSON)
	@Produces(value = { MediaType.APPLICATION_JSON})
	public Response insertPlayer(@Context HttpServletRequest httpServletRequest, final Player p,
                @QueryParam(value = "loginKey") String loginKey) {

                ResponseBuilder response = Response.status(Status.CREATED);
		SinglePlayerResult r = new SinglePlayerResult();

		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.CREATE_PLAYER)) {
			p.setId(PlayerService.getInstance().insertPlayer(p));
                        r.setContent(p);
                        if(p.getId() != -1){
                            r.setSuccess(true); 
                        }else{
                            r.setSuccess(false);
                        }
                        response.entity(r);
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }
		} catch (Exception e) {
			handelAndThrowError(e, r);
		}

		return response.build();
	}

	@DELETE
	@Path("{playerid}")
	@Produces(value = { MediaType.APPLICATION_JSON})
	public Response deletePlayer(@Context HttpServletRequest httpServletRequest,
			@PathParam(value = "playerid") String id,
                        @QueryParam(value = "loginKey") String loginKey) {

                ResponseBuilder response = Response.status(Status.OK);
		Result r = new Result();

		try {
                    if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.DELETE_PLAYER)) {
			if (id != null) {
				if(PlayerService.getInstance().deletePlayer(Integer.parseInt(id)) == 1){
                                    r.setSuccess(true);
                                }
                                else{
                                    r.setSuccess(false);
                                }
                                response.entity(r);
			} else {
				throw new Exception("Id not set");
			}
                    }
                    else {
                        response.status(Status.UNAUTHORIZED);
                    }
		} catch (Exception e) {
			handelAndThrowError(e, r);
		}

		return response.build();
	}
        
        @POST
	@Path("security/login")
	@Consumes(value = MediaType.APPLICATION_JSON)
	@Produces(value = MediaType.APPLICATION_JSON)
	public Response login(@Context HttpServletRequest httpServletRequest,
			final LoginCredentials loginRequest) throws Exception {
                        
		String key = null;
                Status status = Status.ACCEPTED;

		if (loginRequest.getUsername() != null) {
                    try {
			key = PlayerService.getInstance().login(loginRequest.getUsername(), loginRequest.getPassword_enc());
                    }
                    catch (Exception ex) {
                        status = Status.NO_CONTENT;
                    }
		} else {
			//throw new Exception("Username not set");
		}
		return Response.status(status).entity(key).build();
	}

	@PUT
	@Path("security/{id}")
	@Consumes(value = MediaType.APPLICATION_JSON)
	@Produces(value = MediaType.APPLICATION_JSON)
	public Response setPassword(@Context HttpServletRequest httpServletRequest,
			@PathParam(value = "id") String id, final LoginCredentials credentials,
                        @QueryParam(value = "loginKey") String loginKey) throws Exception {
            
                ResponseBuilder response = Response.status(Status.ACCEPTED);
		Result r = new Result();
		
                if (AuthorizationService.getInstance().isAutorizedToPerformAction(loginKey, Action.DELETE_PLAYER)) {
                    if(id != null){
                        if(PlayerService.getInstance().setPassword(Integer.parseInt(id), credentials.getPassword_enc()) == 1){
                            r.setSuccess(true);
                        }
                        else{
                            r.setSuccess(false);
                        }
                        response.entity(r);
                    } else {
                            throw new Exception("No id set");
                    }
                }
                else {
                        response.status(Status.UNAUTHORIZED);
                    }
		
		return response.build();
	}
}
